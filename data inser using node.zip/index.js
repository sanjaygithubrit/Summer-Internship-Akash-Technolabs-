const mysql = require('mysql2');
var express = require('express');
var app = express();

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: "express"
});

con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");

});
let firstname1 = ['sanjay', 'dhaval', 'jaydip', 'mehul', 'bhavik', 'anil', 'dharmesh', 'punit', 'hiren', 'nirav'];
let lastname1 = ['parmar', 'patel', 'katudiya', 'shekh', 'chavda', 'haraniya', 'jambukiya', 'vaghela', 'kanjariya', 'davada'];
let college1 = ['L.DCollege', 'C.Ushah', 'SilverOkk', 'GECBhavnagar', 'GECRajkot', 'GECPatan', 'HNGU', 'Darshan', 'DMV', 'M.Dshah'];
let city1 = ['Botad ', 'Rajkot', 'Ahemdabad', 'Bhavnagar', 'Surat', 'Barvala', 'Salangpure', 'Dhandhuka', 'Paliyad', 'Patan'];
let email1 = ['sanjayparmar1650@gmail.com', 'dhavalpatel2123@gmail.com', 'jaydipkatudiya7364@gmail.com', 'mehulshekh645@gmail.com', 'bhavikchavda5243@gmail.com', 'anilparmar5346@gmail.com', 'dharmeshpatel645@gmail.com', 'punitvaghela7564@gmail.com', 'hirenkatudiya7465@gmail.com', 'niravdavada7465@gmail.com'];
let contactno1 = ['6354008800', '9685742365', '5698746512', '8536451927', '5685512374', '8543296573', '2365498257', '6158349532', '2356184359', '6235914352'];
let marks1 = ['85', '90', '84', '69', '79', '82', '87', '90', '78', '73'];
let dob1 = ['2000-05-06', '2002-03-08', '2001-08-07', '2007-06-05', '2004-09-07', '2005-07-20', '2010-02-07', '2000-09-03']

app.post('/user12', function (req, res) {
    for (i = 1; i <= 1500; i++) {
        let firstname = firstname1[(Math.floor(Math.random() * firstname1.length))];
        let lastname = lastname1[(Math.floor(Math.random() * lastname1.length))];
        let college = college1[(Math.floor(Math.random() * college1.length))];
        let City = city1[(Math.floor(Math.random() * city1.length))];
        let email = email1[(Math.floor(Math.random() * email1.length))];
        let contactno = contactno1[(Math.floor(Math.random() * contactno1.length))];
        // let marks = marks1[(Math.floor(Math.random() * marks1.length))];
        //  let dob = dob1[(Math.floor(Math.random() * dob1.length))];

        con.query("insert into student_express(first_name,last_name,college,city,email,contact_no) values('" + firstname + "','" + lastname + "','" + college + "','" + City + "','" + email + "','" + contactno + "')", function (error, result) {
            if (error) throw error;

            console.log("complete");
        })
    }

});


app.listen(4000, function () {
    console.log('Node app is running on port 4000');
});