 var fs = require('fs');
 
 fs.readFile('sanjay2.txt', 'utf8', function(err, data){
      
    if (err) throw err;
    var substring = data.substr(4, 9);
    var index = data.indexOf('a');
    var substring = data.substring(3,7);
   
    console.log(substring);
     console.log(index); 
    console.log(substring);
    console.log(data.toUpperCase());
});


