var sanjay = new Date('2023-02-07');
var day = sanjay.getDay();

var san = ['sun','mon','tue','wed','thu','fri','sat'];
console.log(san[day].toString());
// console.log(day.toString())
// console.log(sanjay.toString());