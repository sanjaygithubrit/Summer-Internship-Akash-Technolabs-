

// var calendar = require('node-calendar');

const event = new Date('August 19, 1975 23:15:30');


const days = 2;
const gd = event.getDate() + days 
const st = event.setDate(gd);
const final = new Date(st);
console.log(final.toString());
