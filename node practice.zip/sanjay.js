var fs = require('fs');

//create an empty file named mynewfile2.txt:
fs.open('form.html', 'w', function (err, file) {
  if (err) throw err;
  console.log('Saved!');
});var http = require('http');

//create a server object:
http.createServer(function (req, res) {
  res.write('Hello World!'); //write a response to the client
  res.end(); //end the response
}).listen(8002); //the server object listens on port 8080