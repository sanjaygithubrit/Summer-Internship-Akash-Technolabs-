let san=0
let sanjayi,sanjayj 
for(sanjayj=2;sanjayj<=100;sanjayj++)
{
for( sanjayi=1;sanjayi<=sanjayj;sanjayi++)
{
  if(sanjayj%sanjayi==0)
  san++
  
}

if(san==2)

console.log(sanjayj)
san=0
  
}