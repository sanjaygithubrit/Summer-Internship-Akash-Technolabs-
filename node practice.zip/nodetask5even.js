for (var sanjayx=0; sanjayx<=15; sanjayx++) {
    if (sanjayx === 0) {
            console.log(sanjayx +  " is even");
    }
    else if (sanjayx % 2 === 0) {
            console.log(sanjayx + " is even");   
    }
//     else {
//             console.log(sanjayx + " is odd");
//     }
 }