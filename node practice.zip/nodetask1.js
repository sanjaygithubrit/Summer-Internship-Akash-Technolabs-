var http = require('http');
var fs = require('fs');


http.createServer(function (req, res) {
  res.write('Hello World!'); 
  res.end(); 
}).listen(8003); 


// fs.appendFile('sanjay1.txt', '',function (err) {
//   if (err) throw err;
//   console.log('Saved!');
// });

// fs.appendFile('sanjay1.txt', 'sanjay parmar', function (err) {
//   if (err) throw err;
//   console.log('Saved!');
// });



fs.open('sanjay1.txt', 'w', function (err, file) {
  if (err) throw err;
  console.log('Saved!');
});



// fs.writeFile('sanjay1.txt', 'Hello sanjay!', function (err) {
//   if (err) throw err;
//   console.log('Saved!');
// });

// fs.appendFile('sanjay1.txt', ' This is my text.', function (err) {
//     if (err) throw err;
//     console.log('Updated!');
//   });

// fs.rename('sanjay1.txt', 'sanjay2.txt', function (err) {
//     if (err) throw err;
//     console.log('File Renamed!');
//   });