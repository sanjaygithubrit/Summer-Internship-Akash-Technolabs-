var fs = require('fs');

fs.appendFile('sanjay5.txt', 'sanjay parmar', function (err) {
  if (err) throw err;
  console.log('Saved!');
});