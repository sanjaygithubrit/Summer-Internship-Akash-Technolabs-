const mysql = require('mysql2');
var express = require('express');
var app = express();



var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database:"db_student"
  });
  
  con.connect(function(err) {
    if (err) throw err;
    // console.log("Connected!");
    // con.query("SELECT * FROM student_master", function (err, result, fields) {
    //     if (err) throw err;
    //     console.log(result);
    //   });
  });


  app.get('/users', function (req, res) {
    con.query('SELECT * FROM student_master', function (error, results, fields) {
    if (error) throw error;
    return res.send({ error: false, data: results, message: 'users list.' });
    // return res.send(results)
    });
    });


  app.post('/user',function(req,res){
   
    con.query('insert into student_master (first_name,last_name,college) values("sanjay","parmar","l.d.college")',function(error,result,fields){
      if(error) throw error;
      
       console.log("complete");
    })
  })


    app.listen(3000, function () {
        console.log('Node app is running on port 3000');
        });